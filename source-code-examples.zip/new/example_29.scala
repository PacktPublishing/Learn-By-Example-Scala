

def printHello:Unit = print("Hellooo!")
val printHelloFn = printHello _

printHello
printHelloFn()