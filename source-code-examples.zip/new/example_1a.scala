object Example1A extends App{
  println("Helloo world!");
}