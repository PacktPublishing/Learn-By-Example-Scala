val dayOfWeek = "monday"

val typeOfDay = dayOfWeek match{
  case "Monday" => "Manic Monday"
  case "Sunday" => "Sleepy Sunday"
}
