def sayHello():String = "Hello"

sayHello

sayHello()

def sayHello2():String = "Hello"

sayHello2

sayHello2()