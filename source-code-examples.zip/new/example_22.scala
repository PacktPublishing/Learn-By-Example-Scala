val getRectangleArea = (length:Double, breadth:Double) => {length * breadth}: Double

val getRectangleArea(length:Double, breadth:Double) => {length * breadth}

val getRectangleArea(length:Double, breadth:Double) => {length * breadth}




val area = getRectangleArea(5,8)